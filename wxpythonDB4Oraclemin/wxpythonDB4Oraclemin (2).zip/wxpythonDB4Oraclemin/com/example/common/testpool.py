'''
Created on 2023. 3. 28.
oraclePool.py 테스트 
@author: vscsem
'''
import cx_Oracle
from cx_Oracle import Connection
from com.example.common import oraclePool as op

# 커넥션 획득
with op.getConnection('madang', 'madang','localhost','1521','xe') as conn:
    # 데이터베이스 작업 수행
    cursor =   conn.cursor()
    query = "SELECT * FROM book WHERE publisher= :id"
    cursor.execute(query, {'id': '대한미디어'})
    result = cursor.fetchall()
    for x in result:
        print(x)
    cursor.close() 
