'''
Created on 2023. 3. 7.
@author: vscsem
'''
import cx_Oracle
from cx_Oracle import Connection
from com.example.common import oraclePool as op

# 커넥션 획득
# conn = op.pool.acquire() or
conn = op.getConnection('madang', 'madang','localhost','1521','xe')

"""
# 데이터베이스 작업 수행
cursor = conn.cursor()
query = "SELECT * FROM book WHERE publisher= :id"
cursor.execute(query, {'id': '대한미디어'})
result = cursor.fetchall()
    for x in result:
    print(x)
    
"""
# 다른 방법 - 커넥션 반환이 필요 없는 로직
# 커넥션 획득
with op.getConnection('madang', 'madang', 'localhost', '1521', 'xe') as conn:
    # 데이터베이스 작업 수행
    with conn.cursor() as cursor:
        query = "SELECT * FROM BOOK WHERE PUBLISHER=:id"
        cursor.execute(query, {'id':'대한미디어'})
        result = cursor.fetchall()
        for x in result:
            print(x)

# 커넥션 반환
# cursor.close()
# op.pool.release(conn)
