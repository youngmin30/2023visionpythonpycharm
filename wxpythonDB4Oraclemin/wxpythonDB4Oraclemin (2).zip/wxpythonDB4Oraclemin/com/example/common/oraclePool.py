'''
Created on 2023. 3. 28.
WXPYTHONDB4ORACLEMIN
oraclePool.py
@author: youngmin
'''

# 모듈을 가져오는 영역
import cx_Oracle # cx_Oracle with Oracle 11.2, 12, 18, 19 and 21 client libraries
from cx_Oracle import Connection
import pandas as pd

def getConnection(xuser, xpassword, xurl='localhost', xport='1521', xsid='xe'):
    try:
        pool = cx_Oracle.SessionPool(
            user=xuser,
            password=xpassword,
            dsn=cx_Oracle.makedsn(xurl, xport, xsid),
            min=2,
            max=5,
            increment=1,
            encoding='UTF-8'
        )
        return pool.acquire()# 풀에있는 컨넥션 객체 하나를 리턴 
    except cx_Oracle.Error as error:
        print(f"Error while connecting to Oracle database: {error}")
    


def getMeta(tableName, xuser, xpassword):
    try:
        con = getConnection(xuser, xpassword)
        cursor = con.cursor()
        # 쿼리 실행
        sql = "SELECT column_name, data_type FROM user_tab_columns WHERE table_name = '" + tableName + "'"
        cursor.execute(sql)
        result = []
        # 결과 출력
        for row in cursor:
            result.append(row)
        # 연결 닫기
        cursor.close()
        con.close()
        return result
    except cx_Oracle.Error as error:
        print(f"Error while fetching metadata from Oracle database: {error}")
        
        

def getMeta3(sql,xuser,xpassword):
# Oracle 데이터베이스 연결
    con = getConnection(xuser, xpassword)
    # SQL 문 실행 결과를 데이터프레임으로 변환
    df = pd.read_sql(sql, con)
    # 데이터프레임에서 튜플 리스트로 변환
    meta = [tuple(x) for x in df.values]
    # 연결 종료
    con.close()
    return meta

def getMeta2(sql, xuser, xpassword):
    # Oracle 데이터베이스 연결
    con = getConnection(xuser, xpassword)
    # SQL 문 실행 결과를 데이터프레임으로 변환
    df = pd.read_sql(sql, con)
    
    # 데이터프레임에서 컬럼 이름과 타입 정보를 가져와서 메타 데이터 생성
    meta = []
    for col in df.dtypes.items():
        column_name = col[0]
        column_type = col[1].name
        meta.append((column_name, column_type))
        
    # 연결 종료
    con.close()
    
    return meta