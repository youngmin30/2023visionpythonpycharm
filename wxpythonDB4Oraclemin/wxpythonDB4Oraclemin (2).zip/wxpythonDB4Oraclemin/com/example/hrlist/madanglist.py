'''
Created on 2023. 3. 28.
hr 계정의 EMPLOYEES  테이블 정보를 리스팅 
@author: vscsem
'''
import wx
import wx.dataview
from com.example.common import oraclePool
import datetime

# 오라클 데이터베이스 연결 설정
conn = oraclePool.getConnection('madang', 'madang')
meta = oraclePool.getMeta("ORDERS", 'madang', 'madang')

# 쿼리 실행 및 결과 검색
try:
    with conn.cursor() as cursor:
        # 쿼리 실행
        sql = "SELECT * FROM ORDERS"
        cursor.execute(sql)
        # 결과 검색
        result = cursor.fetchall()
finally:
    conn.close()


oracle_data_types = {
    'int64':float,
    'object':str,
    'CHAR': str,
    'VARCHAR2': str,
    'NCHAR': str,
    'NVARCHAR2': str,
    'DATE': datetime.datetime,
    'NUMBER': float,
    'FLOAT': float,
    'BINARY_FLOAT': float,
    'BINARY_DOUBLE': float,
    'TIMESTAMP': datetime.datetime,
    'TIMESTAMP(6)': datetime.datetime # hire_date에 해당하는 데이터 타입 추가
}


class MyFrame(wx.Frame):
    
    def __init__(self, parent):
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="Data View List Control Example")
        # DataViewListCtrl 생성
        self.dvlc = wx.dataview.DataViewListCtrl(self, wx.ID_ANY)
        
        # 컬럼 설정
        for col in meta:
            column_type = oracle_data_types[col[1]]
            if column_type == str and col[0] != 'hire_date':
                self.dvlc.AppendTextColumn(col[0], width=wx.COL_WIDTH_AUTOSIZE, mode=wx.dataview.DATAVIEW_CELL_ACTIVATABLE, align=wx.ALIGN_LEFT, flags=wx.dataview.DATAVIEW_COL_RESIZABLE)
            elif column_type == float or column_type == int:
                self.dvlc.AppendTextColumn(str(col[0]), width=wx.COL_WIDTH_AUTOSIZE, mode=wx.dataview.DATAVIEW_CELL_ACTIVATABLE, align=wx.ALIGN_RIGHT, flags=wx.dataview.DATAVIEW_COL_RESIZABLE)
            elif column_type == datetime.datetime:
                self.dvlc.AppendTextColumn(col[0], width=wx.COL_WIDTH_AUTOSIZE, mode=wx.dataview.DATAVIEW_CELL_ACTIVATABLE, align=wx.ALIGN_LEFT, flags=wx.dataview.DATAVIEW_COL_RESIZABLE)
        
        # 결과 적용
        for row in result:
            # 각 행의 데이터를 문자열 또는 숫자 타입으로 변환하여 리스트에 저장
            row_data = []
        
            for i, data in enumerate(row):
                column_type = oracle_data_types[meta[i][1]]
            
                if column_type == str:
                    if meta[i][1] == 'DATE':
                        row_data.append(str(data))
                    else:
                        row_data.append(data)
                        
                elif column_type == float or column_type == int:
                    row_data.append(str(data))
                
                elif column_type == datetime.datetime and isinstance(data, datetime.datetime):
                    row_data.append(data.strftime('%Y-%m-%d %H:%M:%S'))
                
                elif column_type == datetime.datetime and not isinstance(data, datetime.datetime):
                    # 오라클 데이터 타입이 DATETIME이고, 파이썬 데이터 타입이 DATETIME이 아닐 경우
                    row_data.append(datetime.datetime.strptime(str(data), '%Y-%m-%d %H:%M:%S'))
                else:
                    row_data.append(None) # 값을 누락된 열에 추가
        
            # DataViewListCtrl에 행 추가
            self.dvlc.AppendItem(row_data)
    
    
if __name__ == '__main__':
    app = wx.App()
    frame = MyFrame(None)
    frame.Show()
    app.MainLoop()